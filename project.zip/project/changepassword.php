<html>
        <head>
                <title>ChangePassword</title>
</head>
<body>
        <?php
        $username= $_POST['username'];
        $password = $_POST['password'];
        $password1 = $_POST['password1'];
            
	$conn = mysqli_connect("localhost","project","project");
        $db = mysqli_select_db($conn,"project"); 
        function function_alert($message) { 
      
                // Display the alert box  
                echo "<script>alert('$message');";
                echo 'window.location.href = "loginstu.html";';
                echo"</script>"; 
            } 
            
            $query1="SELECT * from login  where username='$username'";
            $result1 = mysqli_query($conn,$query1) or die("Query failed: ".mysqli_error($conn));
            if(mysqli_num_rows($result1)==0){
                    echo "<script>alert('username does not exists');";
                    echo 'window.location.href = "Home.html";';
                   echo " </script>";
             }
            
            
               else
                  {
                    $query = "UPDATE login set password='$password1' where username='$username' and password='$password'" ; 
                    $query2=   "UPDATE registrstu set password='$password1' where username='$username' and password='$password'" ; 
                    $result = mysqli_query($conn,$query) or die("Query failed: ".mysqli_error($conn)); 
                    $result2 = mysqli_query($conn,$query2) or die("Query failed: ".mysqli_error($conn));
                    }
                    function_alert("Password changed Successfully");
                    //header('Location: hii.html');
 
?>
</body>
        </html>